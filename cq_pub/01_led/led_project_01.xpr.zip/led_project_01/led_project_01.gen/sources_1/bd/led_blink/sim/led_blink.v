//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2024.2.2 (lin64) Build 6060944 Thu Mar 06 19:10:09 MST 2025
//Date        : Thu Apr  2 08:18:32 2026
//Host        : firebat running 64-bit Ubuntu 24.04.4 LTS
//Command     : generate_target led_blink.bd
//Design      : led_blink
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "led_blink,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=led_blink,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=2,numReposBlks=2,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "led_blink.hwdef" *) 
module led_blink
   (CLK_0,
    Dout_0);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_0 CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_0, CLK_DOMAIN led_blink_CLK_0, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input CLK_0;
  output [2:0]Dout_0;

  wire CLK_0;
  wire [2:0]Dout_0;
  wire [24:0]c_counter_binary_0_Q;

  led_blink_c_counter_binary_0_0 c_counter_binary_0
       (.CLK(CLK_0),
        .Q(c_counter_binary_0_Q));
  assign Dout_0 = c_counter_binary_0_Q[24:22];
endmodule
