//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2024.2.2 (lin64) Build 6060944 Thu Mar 06 19:10:09 MST 2025
//Date        : Thu Apr  2 08:18:32 2026
//Host        : firebat running 64-bit Ubuntu 24.04.4 LTS
//Command     : generate_target led_blink_wrapper.bd
//Design      : led_blink_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module led_blink_wrapper
   (CLK_0,
    Dout_0);
  input CLK_0;
  output [2:0]Dout_0;

  wire CLK_0;
  wire [2:0]Dout_0;

  led_blink led_blink_i
       (.CLK_0(CLK_0),
        .Dout_0(Dout_0));
endmodule
