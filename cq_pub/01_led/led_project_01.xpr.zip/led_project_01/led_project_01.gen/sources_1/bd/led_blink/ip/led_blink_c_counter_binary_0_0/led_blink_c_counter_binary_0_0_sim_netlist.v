// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2.2 (lin64) Build 6060944 Thu Mar 06 19:10:09 MST 2025
// Date        : Thu Apr  2 08:19:13 2026
// Host        : firebat running 64-bit Ubuntu 24.04.4 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/tomorrow56/ws/vivado/1_led/led_project_01/led_project_01.gen/sources_1/bd/led_blink/ip/led_blink_c_counter_binary_0_0/led_blink_c_counter_binary_0_0_sim_netlist.v
// Design      : led_blink_c_counter_binary_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "led_blink_c_counter_binary_0_0,c_counter_binary_v12_0_20,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "c_counter_binary_v12_0_20,Vivado 2024.2.2" *) 
(* NotValidForBitStream *)
module led_blink_c_counter_binary_0_0
   (CLK,
    Q);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_mode = "slave clk_intf" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF q_intf:thresh0_intf:l_intf:load_intf:up_intf:sinit_intf:sset_intf, ASSOCIATED_RESET SCLR, ASSOCIATED_CLKEN CE, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN led_blink_CLK_0, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 q_intf DATA" *) (* x_interface_mode = "master q_intf" *) (* x_interface_parameter = "XIL_INTERFACENAME q_intf, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {DATA {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value data} bitwidth {attribs {resolve_type generated dependency bitwidth format long minimum {} maximum {}} value 25} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DATA_WIDTH 25}" *) output [24:0]Q;

  wire CLK;
  wire [24:0]Q;
  wire NLW_U0_THRESH0_UNCONNECTED;

  (* C_AINIT_VAL = "0" *) 
  (* C_CE_OVERRIDES_SYNC = "0" *) 
  (* C_FB_LATENCY = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_SINIT = "0" *) 
  (* C_HAS_SSET = "0" *) 
  (* C_IMPLEMENTATION = "0" *) 
  (* C_SCLR_OVERRIDES_SSET = "1" *) 
  (* C_SINIT_VAL = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_WIDTH = "25" *) 
  (* C_XDEVICEFAMILY = "zynq" *) 
  (* c_count_by = "1" *) 
  (* c_count_mode = "0" *) 
  (* c_count_to = "1" *) 
  (* c_has_load = "0" *) 
  (* c_has_thresh0 = "0" *) 
  (* c_latency = "1" *) 
  (* c_load_low = "0" *) 
  (* c_restrict_count = "0" *) 
  (* c_thresh0_value = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  led_blink_c_counter_binary_0_0_c_counter_binary_v12_0_20 U0
       (.CE(1'b1),
        .CLK(CLK),
        .L({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .LOAD(1'b0),
        .Q(Q),
        .SCLR(1'b0),
        .SINIT(1'b0),
        .SSET(1'b0),
        .THRESH0(NLW_U0_THRESH0_UNCONNECTED),
        .UP(1'b1));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.2.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
XI9aC7wduioAIgpFsF7Fx/Uz/nSJ02wdKTexnXrRVc8Y7AwrUXmZ04wpZmWPPm0q7/DZnMHjEN+z
qMI0SXB9UZNrVY8T2VcPALran56BRS7Xn7WpxI7p+fA+8uE5k6S+pywcaqxeGSJ24sTDWvshEt0s
3s3bQMAV4I09k0C+dRs=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FdEGxC6OIVdBlb9ZR/WypVpZSJjqhRZjiEMiKMEs91j4gTeXlyGInEMjceI4AJshEkdegkXMDdyo
WhvsFzFTqB6dLs7qY7u1UPPw3GyTQJthzlpX8qZSRk7bU2iwO3yAExZCKQh97CnL59fGK6tcTCo/
K2LUqByIndkyFi7qYKEMtA3VrnPqvKxPAqS4Rl9bZcG3giecQpXjKk4H0S7smNnfJJJ93jAUmFwN
Na+20o12PCLaNjGCos5UFuqA/CB+kMVJu06nlAZOz36c6oY6fo9AOjN8JcKIe4kIf6+0van83V3I
WsARCoODQ/8kjfunclPDrHJAV7p7GkYLTPRMEg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
a1M7tEuPM+oUah91/IEpY1Y4VcuHM6K9PzmWmE9vD8IwnUN38IzNXenEnfgBZcBJyNP9uwHsp+zR
tBxX12N+WtcrQFbPTkHddiy3ej+IwwMNFYhl1OpfIBqszpvpbFwx71THxgRCJ/Lz/Z9LZe7P0wdN
HjCMxvGMMsis06E2hyE=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
jJz/WeJFEgoKUMmg+kRXrQJNQnoOzhjGgLPp9x8u5pi6J6rKRf81w8rxoAu63cX1H0ncswkbU4/s
XkaYLst9C3R/nhA/b0VrH1CqdJg04RBW7ECryQ7gvd1eR/5Ngm65IcGOUFnnC8mQO4AP3FgkBEru
hN1zQFE0X/qW8Dj1Dm34+vFjXfuhHk4wrE7OgEtqyYwX8bMZ0K5x8pSRiEmOAh5jPMMIXQuzU0uW
qrXaRKue0MrYwDENLXpBYjXYZ/JkihHEVXAXCG4q5jYGXCXdCyNUnQrgPwTV7iRAchEe2Uzibj9K
9tZXhC1DpkqSsIlUOAAGlpIo52sxD6GBds/Gpw==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
cFn8Zw/30xh1hih0O49uJrRULffI/EbPs9TJp4pba1//F8S8JVqhcc1Mp+7pbsmMqVvFU9V70XJJ
l9gTpJLPDS6nymWvUtbqlXQeFnjQ8kR0ZmZrGJZS/Mb0n9ouja2SFNuxcknKTaeepm3SXdfQqHIz
w3BQyyZm45Ok9iVPNIaGAzBFXIlZp9HzJljzPN0fcpc/p7FLPXuU/vcFY5irrUI+88tRICMEbtQP
NpbSMVJx9mKJBKL0B3F7PlQi0heDMn84nvi/5aV4a8Zd4eXE0IJTJ/EmNLizcxp+AdQFOyotj9zB
SDUE7zULdgmHo9Tv3X+BCvXuy+EbjRWqwWwP2g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
T1vV+Pd74RqgcvCDqdyvd7MRhl2kNHHjaPMDB3QMJjq8aglMWZOd/r8TOXqaOfGNHDHrSsWnqHnX
Se9ePoB6vygFvEE5n39nw+aDA10Rr7uGeNwKUCoxKf/8W0n3ooV7xMeYeHTjKs7uFfK5ORGIhLUQ
3DatTYTKR6NKDqOoDs3SpNGTIrOjwzl6VOKLuJ/KrAeRyNMZz0gVvbAYMic9XlbVZWoP+ImsemLZ
mTOWLpTn8gMkFbgAu8KBY9y64UDQbWcncg+fMIBFKVbxFam+FEbL4wZKHbQ0Hx+MCtUWpFbCIux5
ZeiZFT8q2GBbp5kebFt7l/AQAKSHZ5U+dLFy5A==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ogDApgJt11lksSkkBP00G5nffeu+1zi+XN1z+OzcKWHbk2MJPeNvOyeongm0Q2hjnkRWu4lL6Ha+
w8pud+EzQ5c9o2T9ip8pWOW415CCBZawG6rT2rxt/bToM7DIvkNJYf6XC5wDUB2VJiu2oWxkl70I
/alMj/1oTRNZRmuPGn4H9nC1wmo7n3g0DRHtn9N2ji70/oTLNdhZd7iNjOF5aAKcGuPGbd/Nk/3r
uhQyajt5P03YA1z+b38wA6L3NP1oe4V3yy07XNYZyAi5xJJ3fIhMPfwNyL+60q4v2Mlwg78pcxVH
0hD4Zbb+dfe63BXvjhm3n3+qGBx6ISZhFhWksg==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
EaN/g5RBweicN1k6qI3bL/Fvs64BcyXhLs6cIyWpQBBOXUiGEOP/BZEkB02YycmpcnoY83e0I8Gr
Ehaw+e/jGyBc5+f+wc52RWwOXMwYve2WxAKz1EfzQN50CeHTusUiTGpZjbcxbehqfpeI6C1LASIc
cz2PRhvn9H3YThlQqoMfQqfH9zARWepRcvfS/FLbhO60Dl/PxuXFEja2fyt1OCELAtdkxUeQYXG+
P9AOuPsi4YhVhDjPASXwr9H4jKaOmpDIndehlfmVCwM3cMihUXnyN+gLNzuvfhvmhQKqxpcBpjKd
42voyKD6SdZm9+VHdv0Hk87y4U3ngC0mkwj9BVWLylLISxwtGNmAoXXjw0WaHKrdU/ZnTU6vbCem
+fAxJ9KM9Nn/Q8Dc34PCX54iJoAWQs+y6TBvm/xK87IUgSi6Pt1zO75PrFt9GhnFFcvHN1qY6vDr
iUYGL8kJnKofqacTFq4dXS6m4QHO4TQo5PnV0NM15W+Zbh08yOmG0zzc

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
NpKjWmnPalUiHYBj+ToU0lK6wrJiGqvGuRuBYbm78Xkrji6rhVlO67KJDFoq8rFIedeMRckLuIhe
L2uiN+h9chloL05wOQb/vXxyG8Ptk71a1h6tbVkdj/yjfzrWrDYUrnu3Y9N/zmfXa8lPjwQpfUk8
WndsLXXAe4b2uihsmW3iIsAf/LD1VmDeFHb4fsQZt9ZTP/qp/xk7pfXj78WZHiRZ6KCZl5SNVbci
P1KzkGowKrEP8EWw6YXys2zMsoKjtnHwEa8eiMkiQgnCUH8C69gMvcIN6jogq+HVh37MW+ZHMOMA
zP8gBV1PrjrDEXA73MilDH1AMRjerGa/ytckKg==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mroNA4yfeQVfEv98CuClrF0Ki6Hh9blohWkCDBXxMWOc09BD8aD0lHSUhUVKLDdMazo8mOhjVnH/
lEKeKF0w1XoLS8t+f1TYaydZOH+CxMwkJ6YAFQlmB4cQRnvCSuR7RyQo5F9rbEefed6RNqDJLTEm
WPkW8+x+VzJuMAJHCdqVRzk8Zp/rKkEF9OMDhpWfLoI2ljmJ2BovQrSGs7TAhs0twqfGHE+QyZ/8
VRXocfNsgihZfr0Y+0Sp+ZX+0fR8FcMalUBr5EOB87Ja50a0a19AbUhrg1TRplZ13U13r9s7jqF3
v0P/z/dnG2S2ACcA/AtRqlR3elLdT3d6Ufp7dQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
o3AeWu5E7vqTsF11rROBkuCbQPviABKHdGyXnVzB+3ccH0ii+Tu3CLsXWRUgW3ar8VjSVI9ydK+Z
Mkweq0NXw972psUY76R9L4QHrmBDv/jzsZGbKGF8xNNOHsuzAafsNfh/mAeGNUPMwVUtOz7ewdq4
3F+6ZZuafJGkmmKLDU2lDZg2hw11emAITSojq6wDhPM2pWKAiiR7QiCRc4H6hzeY+00nk8lBtiVy
ssI0lQ3N6YlN8ZgC68d8tOIiWldTiIY9+s21Mx7oGcawOb6X7TRecUQNd9ulus2VLLJlFfMMWBVz
EcD+wt1VuiXZB4VJSpIWaRV3vnq2rs11TyZpYA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 2464)
`pragma protect data_block
Bl3e50AatBbimeMAK8F6g73kv5k55WYkpgc0kBD38a5Czbku0jH/BCNLWAn+gwKyxIqmXdF2CUP6
Mj/WtxGGgzBLqdQwUi+hc9hpA0YFbJOaVFaGzcKKs2hhQzL0i6fX2OaIEG5zJ4er715BGOqXDTuZ
+KFjstPdsvFoHiTPEpSkssaO6VDT9Qcr3aVvv3q2CErJQfCGabhlNd3xK7CEHR6ZAhUp4m0R3KU/
8C/zjJyzCzvgxB390VNF7jqM/ZEh1TvcK7j710N2c9unkRs+RLPiDZ8WqCnx41eBQPx6QWMPzHXN
8GOuOqSyD92lvbFyIsuIQEqLracpEFPwe8qlidr9g7Uh+mNp+hT6EafjdcBHK6n3biL10v8455as
pI/F8w7830jr0hwy2KasIqOMF1NiAtdFuHDzsK7woHs47yRANnQYvQ7v9N5JuyXgOnHa7OuYQf8f
sn4V6LVxd2RCUB9Rl0aa/3JutsjyYabmyHKvrbBd/5c2W2LVYBCkd+ve4uK1T9EkQsEz/Ek9i0Jd
b3qKUXbhykJO6LlQuWFFrLfNMEZ/8l10mYumW8FPVZqXgyJZsrupzIsG/3jJUqbbrqeRuH3HANYQ
GlcxqY2ISko4ud6+QB6yPWiXrOXkrAtzhp7vi4Bb5x4N387iOsog9mTHo3U9iAzweODLKHafKQrM
V0QB66j0oxVGXcB+gsBEwto5wqh2AcOXHbrJTZRDYQRi414PvlOTsZAcLwgnCXBrSS2txpUmjxOK
199/Ow6W7Ftd+116vpHw03XvOrPoPyOxDS8QGqLBch1pNM2MfyBO9aYsN66668MTc5Sf1yaCIZVD
amfP0qYUnRuX6+dhKjLz5+Gfzqu3wI3iLjzlQsIwwFNWOfHgZLVw/HKYgvEJgBpZEmZaylBxwgHb
OLYhIc7VtoHdNtowmPoT4F5W075S6pH7zlOsTbCj21V0kbey6GV842wAYT9cnlxm4kyP7itHZr+a
ewLsOcX/CfdYouKnuenSdIu1dSRF7mNZ81BQMl7WObEKZCuk2VciwpOI8dtecwbXQ1uJQxgFOUCj
gmb4E3cX96IV1E3MGF8rY3fPUXKLka1I6pZCGv9pJRlotuq+GO54uhQNhYH0kn7CJT9Z8+D/yeaB
FO+HpgdiiY6Y8wNdcHBeLfr61kFsMk3wSlb+hVaXrrvKge1rr2+quP+SYBYYiJFq3FuIQCEa864k
kuzipXi8/42Xu43Dww6S2IsNnmqlL4vz2M4xncHdbYasG5C2yafpJQ1+7gZhwMPHh5ly+amzFJvY
17x6Cdz6XHc/AqcJeV2BOslq+H7NvdNYncS/nvqCADTMmybvSuba96BavH0k1LaBY/ELTxppX7/j
gtKR2a8Qc3Sl/0FBZdqNwQNA8KhM4LTeaioxTd3Th1g6u8c4+pYtZpI/HC7HfQ/kRVIeg6uSm4jM
5d6OIqpzZ6RiWVdxexMTV7NQexJYeaITBuYFqKkjXjLIgTSX5iYo3F3Pe/1vDLiGmxG3Bo/HIQez
oXOmQY57m4WZrLNMblzoWKky4pitOmOhYegxl0oRVhgpnGDmuz+AshOftC14rexw2f5KUgJAKBB8
Ihffw91V4dsOZD+lCZHv0kaxC5gpgI6vZAwKM6jBiKNqum3izZWwDHGtKDe4hEMob4eHjj6C5eDX
QeMrwQDGBpII8mwM6dZjLSYsDZZuKaKDvUTvddIpStRQMqujhxs2WcnohNKmH6B/37royUbe4ltJ
RKtsnCJCl9z2Fz3+2ebREkFMypXO55ltM4M5tAilriVzlXviNhpelPOPaq8ZyCeH3isKNSTylo/4
Iy2+8KlrqASp5US9a5wThlzW+9uoG/VMkNfVCv7250kNTz/vYjZyOr5Bn0KMpOZOCZb/oeSn1qwS
Pbb2J8F5PigGlrAITkn2ZQ9iOmhNY+94CxK3hYF7JgYL9V+xvEnZCCmrKPRjdzfYY6LsgNjMyhbw
NRqdEqv4llDZavUQJo0du8HWJzQ/oOblG4Qy4b4vZ/VDiuYz3LYQhzw4eHL+Z/zoqfBsNtyxHWJv
gxjkM16KLwFo3hsyQvRdq1UC8fbhymwYu/x3lkaM49oQwZ1JoquDdefOLvAP5xjdRv+GGk2Jx/GK
a9C8RNvJ9Vd3A/3Q48ZjgGBTtfCowy8uUv4Cwh1xP0yVM+Ot3RWz9psQLt3YiTxIhkcYz+zMxcoT
XbZeHKXQLmoKI/veKm/Ndl393+ITQngI9iTyTQvw1RA8c+RLYcxw7qJzKzLyFh9tvJEEdNxJb9za
97HnPKk5+6P1rWEy92Od+ce/F1iWdYpVkblIb2W3G0aF3mKonxfYgToDifPFDI8mpCI34lP98dAG
aGdG7gfKQpLpQrDUpx6Yq+yJuuBmYzH1lGA+GYXDTOBAie0MjiYLdfuMgL6Za+qFnZA1/2SLMPqm
/SWPC7jRK7ege9m0OsEg7zb9X7amTWugWaqEFejt6E1JrBFbapS3Xf4XxiDSa2EYW4OLZCuIt2cA
ejcKenqXfHWYyjSGuqDXBiY94ycCe4RFCmmk/KiNimBHj0VBhE/f0hCQhu0POCPRLYK558HKv0wG
V+LLBCy+NukmN1lRjYR+kSABXnBcA1sBOGGG4pYssgfQvKJpVFr6ublXTa9SgDT64dVeZ+oudWa2
kk2scIgOWrPaztnMafOz8eQylZAHo9KFjGw3d0jHOmLkMIAAX3MlZ4TWI1ZPxst4Tq5LUT7BCNtp
FE16VwuKmITxLsrlK6362o44uPLzxhK1mAXc/2hVvQjwumWFhuW/mYlQjSSMtEJakpNEOu2fycs5
z80BYVMlx+1QcJ1hQCBv7kbDNJv545FsvRmtYIjSxZz28FVMxm9RLIjIeg9SwU0pnGbyYrakxB5D
WdlthEIIvHrhSf/YEReJLAwRPls7B/auiRq+ldN0ZzSG1a2WJJnDv+CbUWng4p25x8VnRjrH8bJx
wSHnd/W4sx+GSAwle/1BZrm5eAixj+YTSx7tL8cB/GdJU6R3wLhDPIaRis+o2Zjl7RskWxi4zmH5
hPEZAxkMx6BaxqaOa06+uUff/CEeSPDqef/pQPQkq6pQ7NRtvtiQX38nZCxOeE4TLqrB2SJOFmps
nX5MO7AybzfOs0aSABfYikPAWa8DvsuKpLLhqZCj6LBzpUyGR8DyFO/npB5J2ACdJchNMfG6D32q
TTEzfyB4V720tzAPGioRrY5SHo5cd3EEbBDP8t4K0/dPh7bW788oRYPsTGCuXu3dlCK60dWZaY9x
LqQQGIdqPrf6UDlXFA==
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.2.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
rUzNpLonlHZueYbtvg9kuETAPy+QvnLhK5nwbfwAlaLf5yON99QRgDd55NjU3eBoPrIt7hDobzZW
5h/tOWsFmorgkSi6J/Vx97wJfARzJs55xxPTIVuhCbzktHS8ETQTwBWU8ejEv/sEFbCxpZtN4loH
tb091pUBHOCqTAKCmmw=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
OABrocT4jXYVjEBAXYVPrBOfFFp3kF3ZclmfS8RMb2WGqI/j7+ttdAsNCA2JInQf8Kn7KB0OYBqg
ePt4pVAKyQXc3DSXZsGm93HQiY2SDHeOSAo10M0+sYuG3Im5r5KJFFq7R9ISmemIeFAUL/1gz3Q9
QGmORlcBsVtMrXRQv+znvhkQKhQfWvd02x2Ti39AdfELgqEE7fMXWUoHPGE4NOE7EjJDdHuRA5gH
0+B+hTOoLa5agSuihcDH4YAd6zEGpo2BLMXmWUg6v2562ELw3A5t8TD9FeG87kP6/gaZKaf1RkiK
gmQTzZfm57Pp45t4y/DX5Gz7STLIA50i+phRmg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
VwzwJpryXRsUBUIrVkKHBF9KAWfGpQK3PWbyx7dwiIU30c10YJv5P5x3/LO566D9SNZpys5EyZO6
h5BClKWl0EPnVyZ/FtnRmJjhHg2VFFbvi5F4hTwvltUnBYGMR+6dzGNGgICt35I69/5vgCP1LcQm
y/JbZ4PgoHylPW3ncfo=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
MfU6iGw8Js0VMg16xEuyiN5XKfVD6s8p+rQ7ZPRlVUT6EBOaw2KT7c5/+kvYG8/uUP8VdxXBQtR+
ag3eJRBMtbwTBhFw+UqzHyY+vUyzqO7ikvg5iG7oMStN75G3qJ6TVeMagdq7rLYBjdFWdxKJDJA9
SFwsJ1jN0LouMdDrCcyZThC7KCttnwgMgrLEseiM3+A5lJTXsFt36YT1l6zDguc0Otd2KneTYx5E
LRELDLn6Xe+o4DPp4VLP5iCw9WsVtaFhIO5KiZG0XVkjgOTkLPBJobIjHvM4cIEEoTISq54cKAD2
9L77tOG6vxPJR/uyJcExzS8pOtS5uSeiDCd71A==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
eNxxyq5cAn76eJiJpIJsJIjUZrzLAxCwpBVr/LVeyQilhdPV3QVD2fapu/0Gy/+/ve6CS/m9+F73
/Gl45FOewSElBcG+AHODT0gvwCUvEzaL0g2qhaVFRj1OmToBg8oLwAvI+HcgrwwByjvSRwyrsnVz
C6CxmvEw13lpaGGUKd7mfFwffLAwoAIxrVYZGG7n+PsbwczBaCQgn8WDdoPN/2C6FowHV8KZIAx5
IU8M15Gji9pCYUuSH2rcJxq8aZAQMcjDLXpvckddJfG7Ftmgx/53rc/EOCbH17DhcMolQFa1CwUL
XFFJdqiiiRJigykYH8HKJlJQ4AB0LCt5sXE+DQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
LMllGpNtLhbS4oRoux1i3+CNOmRbE7s6YQUXaE6gR8Qi5XO9J5357aNzJ0VKIlPbfKKwPGydf0RH
YmueQVC179UFBpA0eMcrq7Ax08S4MaQ63kyE2WhzKv0pTTPtja4BPQU7vqU4r+lqTi/S3UClHOrn
/Bi2yljhSlaDViip96Jpcnyne6jDByphyzzBvMj5L4qYUbTl2Z0RN0bDOOIFoMaqlotpKbHrNuPh
K6dOm3oM6UZ9iEZva7d3KcRgFlJSxQ5mUusoKVhHTNEeNZGhfC80YS9hzvGNzoSdMBuJADR19tCf
h8re/mcCi/2rRe4SzYSX4V1h2ehRiSUS6NXskg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
pFWf2meWGE2zabuR7ICnG09Fd64DlGV3Sp4SP50ReBYpgkc6/zKCFkoMA1BXKDLi6CKQ/gdSOji6
q4CJHpR888oBp/wpJwuZldfeSausF//ngPpbdqItyHMreNW/W2lQJBxGKfvkvC4S+wJ/BUu5nxh+
Y11bBk6Jrqlf/wN0EpAHAaYqvhXrwQXG2bSxoZ4QucU9Sz9Z3xcnT1pyf9tnCJfqMHL/DRyb5c8T
TabITEQvpnXuz2KDsR90Ni1BAiixri6CoxmGcchpbS6wPQGgYHM+GMPVKx8q/z0hD1DkColLxMqa
/dWDyC4g/UfFzVtgJNY4XkIwqjgwnjhW7Fd5XQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HzG4+kmfx8DnE7Wyh8ZgCVPOfGBft5nCeSqLM3LMqB2akwTQWHIflCxOVHSHrJGlXXaip5824C9B
5jL4CI87pwdES/C2U2dn9JYlHeCkTBVdcoWnwhASBjPMOanOmMQ8VB5q94QEaSoHy/bgRhHWIm3x
7qDBERMOkhIxAl0Fr52pfFIxjn2UQ/vNrIhtapfY70veEqxf7oEMMyhPOdmncp1i2l5iwmN01Cqq
1iHeI/WFJxOhjwvK+7iAN8qiXPHCeRBgv/HcmenY8T22ObwVeV38LtAE71Zt3ams/bwUwE9r6roi
iwlc/92lQHfBbvnDrgTNadkFDh5FJa5uoLlYAjFv1zKuBDroZkqjZs266oLjseOL9pjfXjeio4Wf
d0n8X4P+e0nHUx1QaSTTM9ThUkkHuKQPG3c+9dm6WSbhMaKmPfHW9+Sc8AdqyMeNuY2g8d65NCad
ZOmqYz0Q2k5JWGgQHLd4IQuQcpUNS4PKzGMpa30KaSqkb7bP3cVzoFzh

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
N0dVTQJksnFy4JPRu3mKFI7Fm4rZ1owFs0HY9ZkJm46S8JdK2lYy70FQDFlEY4o34EzcsOUFIBi/
ZacatQgLUv34ozZKGoK2IHZY6iq8wKGbatI1Kh2a5EWE8CafxsLPz/VBod5mHY3bgb29EcuRWg5w
vnEsSb8VMDFHDY9Z3ln5BP/BPTLu/c2YEh5jEHHD3vJzi9mHNfZKGrhS14tfqJjmdNUo6+cKxpvW
unIw7fEpfl65ksmNA2UxQP9J4keIVeMq3u+Yswbc9XfMakTOGecZijxxFj5AQBEmKrdFbWJS2Y6X
WI3n91Dexdu8F4SLi0Ev8767aVivc0D/WKbsQQ==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
q1bGpCNomMwbydCXKQqqGftPr5WOAKvsFQeJjTjIU/XQFdB3nNvkSsTy7xw+IWiGD3RiC2vtOSlu
LYmkpAo3KYAze5Hz+p3m/AMhqwPSLnKyDehkJ71csSo7TFu6IfmzV9xatcqYvW6MelZwaP7aoirY
uGq14Q0gAY9d+mMwFSuooS9UpfTMDvnorUH5BUGo6JS8LQwaq86yyorAKoznzVeu09xXduWkaTpW
dvBk66bnIErXn22dOtRSpYdCBVvMbc4NoG+eER7Xh6WiOkC+NASJD1fjJTMPxvU8zMQHJpyi4T9X
81dYLRJA3gG3eAP7rE/byQcWnZe9CC4kPIdEGw==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
BXm8jZN2jQJQgnETPfnsMmDQgD3QPipyUb15ICgzSH+JJIOF2ksmM7V4Aae87Xg1PnSdgO9xLc48
2NkohMfVrHsa6k3DQZanLTjRCJ95kOKWnX7UWn+YXQBQGvBVa+YPx7Ng3oNKo0TVTgxqv7bywmzU
tuS7tfO0Mu2vS6tLxffA1Vk1ieB+KTY4KJ8JTtO1nHh/rJpqO+p2Bufzq79Zll+5UkB4mZTl7lkl
aCHdBnWchZdTVuphav7nBMFJjdSsxpotUE34Lhl354vRyvLC2SqT/LN/0XBvBpD4jizZ2IAE+qws
ZtV8Y73086I/mIG6ifD0ApxwW3d9pyf2V6YyoQ==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 14912)
`pragma protect data_block
fgNAIe52Qf4TD3je6nT9F7sNQ5YrA2Rj+C6CrRBHM8r8sobKm9Y2+PfX495TTGLk6dIykLiwXAOR
cft2iCtkpDCtoEF4/bLee45n8seLGPDO1wKLbfH93QUMBwY0E4WizKNOCU5QXkglv+ajdIGLS39+
bBhQC71SqGRB7iqA9HZOA0x0j0JpBS1S0Kkvb0VqlyCzhRaQHq5NlM3pCWFWhVt6yy5TM1AQ0EcH
qIODuqZWxUjUywviVju0UdB0vlvmGG894BCR6fwVbYZJdj29a7MePBCX315mkEPf8lcBJzbRXvs4
rF0cqv1+Mazb3aCXeK2BfiM6J/2wVgpIT7F/2Faq4FyWT/B8cSonrsYNOjQI8+T6HgWTljNa5UX0
pI3yDjXSW3fqJ3qRy7vUIqFfzJfh2f8f7eAmN/zt2BDHqfRr3WGn1+SfQxo/4ZwSl2Q2oYuCfot+
Yd9q1Cdx9jy7NIJyb6dCWP00LTPyR5gSSqoRbvTpE3p7/8tWf6f5V2pRUxt6WWeDxPfRfKG5jsnj
dVgnYB0NsmufQnhqha+pYjY0/aGo5YzgBYLvEW8VthMrPEKpJ13wc2Iz54EwXFFQvqd80ryu30hM
aw/Tvhv3Rx2FHKTz23ncIzWwWxbcEeW+2Ejh3gWV4bLjnrwOJkZCDFS+Tszts5sjAaI6HT719AUX
hcMpQrWDveVlnpdRFndWBWcvlkRJQq4wxJ/ynZFm/q5cxUnVqnfND/4AcSJ46yT9YYzh/nwur2zF
X2HCF74V/efU0qR0tC2egp8rLmX6Lx8cAPr537Nfmc/HaszE+223mnERJShZj/MpVGMcAKU2GeRO
+xYpkRAJHRZBH0+sDGHOu+RLh9Sv0b+SRBRmfncS2IfVhCrqG74qZEOkZPor89FwTdxgWQWCMqOg
cIfncnxV2mIOdXT8GCI0zL2AScVm6aUIFSM6en83phrGV8wPQ1g+Kj59Sdi7IX/LZ9ltVvEr1TmN
EVMxpme1jbR61/yoJ0DRVEe1mS0bDaocG0MmsnbUDKqopjSPR9mdbmAXIuI3gHyZyeWBOch0f5DR
AE44hOsxREn4d1BAlH1Kqn/MZwcNHkOeQj98XqOOAg69YBoQ1agKF4tZW1Ny+a5sySeTYh++8FrW
IcqZ8yfAnqbbA45wh1VQ6aTfViSbPMMK2rVtuJMDPBqOPvt9iyXwfJFOp+GNGwefPaYTAl5xmu2w
mtukXbTZmV+rQzs5+XrNpt0f2hZk02hkAQCvy7fLIE6pgP3ydv2o0Fn5G/tcqyVjQ0Qw+vkvqt7R
GuNn289IEeixDz1h4S32/fuMkFhG1mwd5+M8tXkC/L+hPFA8tW9KD5Utp9gjwZ/IG8FndJ91xDBi
l7zF8XBaqP2m6cMR86pTkEpyX/sSacMIuNB6KhusBxjk+U+3GkKmWj93ku9Qofo40NUXUsEF2A87
6aAap4QH2Q0BTsVC8KXYOgVO0cnomTiwVXasVSjspqWjXnVEgQy7iL8E3nckJ/zcHADzlQqP8oI2
NOPBwPL1gw2ojfsKLuw15Xr7OP27GTvVyhcg/AMpgGtP/5faQ0T2convR6iejpgbKMPFDOOSiYWF
w/XUniZegkoGUmTnVwgY8LAbVAWbohWlQksdCyng8iHZ1Cck5xfBCvY5djf9LVAy70CYU0Ut+9p7
i5xQWX4D6LCPpt6VKFwvZy0pecr1RxfHEiuixdeVTS2RJIAEIBW78Q7w76FHFofT6Z4V+vLocAVY
AUo4xDX1CimqgRqWcnDUXaQMFHhlqZN4c1xaLBSjsl0Wr9OZItBQo+c8B0us3iee9r/6yL3jdbaf
lQcaSaJi9+rQJvGTqJAZKBNsHnRswCzDNFJYSpx30/U+TEvR5nfN0nD2lQcngYy9/SXZAVZLWTS8
CioSNvkZiQ6Zt+GwPp+aIX/daFCjcNaBg/tOsWtZLkvi6rBTa3UUbZ4fX6KIopR1fK87n3Jr4Hur
86yUow117s3E6LjNUMFkG3TmKBB86X8K3fquqGR7DnfE6WVleiKiO37a+cDLe2mHZNDcQnM/9l2K
XD0coxft5OazPt38gsqAm/VCfxm89Y16TWUH8jUtVwBZ4FhedBJB1bhTjFFCGOu9lUIiyjHw8w0E
FaB1xhnvVxo1gnheMXJnt5+luTaLrJ2gooXCBOt7QZeapT250acKz29+Y98kWamyrI/Xv/fxyvRj
AdBs9y+xy1Ewq+HKhVDSJYPDkR9TkI8Xq5InHTlHEKqZtQIUeQo567Z0gOSGBnYadQZIbYIPhpdw
b21m/KLQp8dSE0eCvSBM2J0Q82ftt9Fccgb8ZsDWtgCZAXmx9mJrZGCRHaXafaJYbbR9eHcffV00
ur2Yr/zrEvgEFrkm1r7ovny9giMytHw83SIWdYImw+ruEmA07CzLmzO0NIElXxohQmgzUSO+7Y3p
4yyUkRAg2bdqFeTBNh7o75AubzjcM1b+nn2F6EqrT8Oj6q/2mgZHPSPfqolcY7uD80jNd97sFe4k
fgA42b+2emOmPJOL01OOo9/7W4cdZFXVGSy8cXDXzuuWoqSzj+51+PMDT7JfNfzt8a38KuQcZ+OW
eoBJkHywtGmRoprs+G6DenTKqInbpJSybTODR8G/jJi+VW22RyvquchpltMenTe1Ld/j0Ej2Qv5b
GpKZqAz3jFONOX8u/V+RXHcoo0ZFE7ivkNwiruU6ZGhMgSDNC9aWiRIpkXB9ovjFkTz1wHMMJoxM
1JCCmdyvyS45R6xU6YPnfeQAPs+aVEaeGHUwaIoJB/Yq3jcgX2dMbYym9y1PgP/SZ2C9TI3cZVzT
ZStQUHDnXeGNN5D9rSM+2G1Gn+wZOIuZira5r/hH78710m9GwhmuEHqpv3g3yswxAf21zPmffGKt
wh4FXG759KwSQao/nvhAVXvtJpvOV6GPIzEYeJfZvYlDwpmoYpe3x45695xSGzrf8rdsS5SIsmiA
181QkVHQI3gquH1awidymcqg1EE/7rNuSLiV69dy7ZHWgScaMApcZNUIj0bZ6oOiDbwPhQ9tnq3X
ofAnlgYKYOKQDP0F7MlYOWlyKKu0FKPr1febLAzJ5jqSGdQH1AlzvbtpmnLW4mHW2v9jTgy6sbdO
64RJxS9QFZBLw1hPaaJuWpqBM+LYM2eQ0nmMyL+n9kCymNYc9LbtfbMVM63Op93qpevl9B/kCD5y
R36G43IBQHPCmQhM+gJEzVLrI6dScYRTCPGHkOGVuyVKMi4PBIzmHIm23tQFdGruDtvdEHt7pysV
UpLYvCXTdHwAU3VoLZ6WyKHeRM3lXeooqBJyNAowcMSghrcJh1Cw0nq0OMPso/03BzAo0gIb5pYn
ZAdaXHsrMAcq0FpcieBgFfx72Lpob+nscoEUGqtktG6reL1C72QXcAm62DPQ0bB2xy67E4xKtxwe
BNT6fENAm/VDfaThq/dfh8nNMGFsOWg3Nm7kjx8kENV90eiILrtTHukeeY6b48z1IVtDS/3zcVtU
XN3gwmG/Peo9Eui2x/Qnrr5kOd2rGXY858k6AgDJCvMfWpvBzYtdxlDyRUV4CLgKms6jfpB1SPFn
D9ZT6RK3QlS25NfRo3Oy/06E5goT4C9pSGnywRlsD9fQJoMQgjtO+RRvAfp8Sh8IvNDokWxHtUhV
fjNxmYY+Q7XC60zcZBlo50/N+r5S1jHmoJnW5nPfI0NPNjHE/BWrk1+ZBlt/sdvYN/n7gkmZQJAV
PJdOmaSaYoKNVYsl4sytpXjxjJa5HVTOkfXFkRPZiUDrC/fROkoIErBesV3WIKBvBMRbIKG28+cP
24aQKCR8fvwXqHWifSLyAXorwC+1asL13Ir34bpF2M2xl3CrG0CKiB7qmfViUPkCso630rIPCjGz
Dav4ejRHBnWu80L+p4cp9T18uEg8OvZ9O2eciUS5hdbnRM2e6o8hCHiiuor0DY9XH8nVPn3rSYAS
eUKsE+Vn3//G0ipt+gfwCyd3XQDbAseaKHDSfKVQYLC7YesXEOKHyhG0g9RZgZUseLVDLuEQ5b8E
3i03tRDmQEUVnYSd5EOmYedivh9tu4JGPpKc98GLhq/v5HSF+W9nTh2VdW3ZkuC6kHNaNG9q0Jv9
D/iEbumDQDEAPV5frlJNOyUk/YCoG1deecaB3nu9XgRDGSFOB/vx4EQibYCshlbQ4G0j8YoGIKb1
dqpZItlgsz55VUJ292j0wTNgioIe+q19woAtug5wMTwlOJM55odT665h7omW3tBiWaiYSbUr6Bxe
kKWfKwa7naJ0ML+G5FTCtKNnMzv0+gwED4Ryn97dEEQf1x1YircetjWNhVUgqp/mLzcS4+YNyXkb
LJ3fVsDK7caWQc2QIvZrZxouZLJqXatEy8gVYWgdo8HtQN2U7K9LS6aSmgJBhvdphO8wC0GsF5/l
fJhaYPRLc54Jm87rcFdKWXkVotWo5xCvyu+7Wt12pTls33UOCD2MDALOq+tylzKtfqyZmABjr/FA
0KzX7Fwhy0dMsG3ycHImasWyf+I/hxm/XIACdTleY70ucnW8Zc3r3ruqU9VPnExcMwkI2i+CikOZ
zWMqgwFC6o4H3GvxfuXpx6jtARqN3GTC2EDaLfoR9ZKgS/o45KMV0cx3uWIk5xQQ0RQafrK05Es8
2uf55T0Ge7vqG4oVgrAtf7ZTP5KEWtARis3xqS4/oGCE57iUgUyXy7y5babkXGehuvK6uCBYrTq/
9pOgRwvS9CEpr9mvbr0QHKuCV/WFE4dJPWhSUKgsnzKxBBpd/or2K7tqVX3qyjk8yrnVLM9f+cjO
FvI8n2QvHH0JzI0cv6xkYE6/+yS3F0YgASbGLwhsXL08kSv9QkK2nzoQ0TfuaM/kRDXstxE8KWoT
jun15czGulYuN4fO3EUFBs6PtAXcPeXnUmAIn/bi0E33pR4b+iBVvbCR05XGdZZKpSqEty3qNxEq
XQK01RDQlSDtmqM6JQpPQo0zOLdOw6+9HVvGygCkViGMHvUqL6QwsmGTeOluc7/JTFE7dueSGsPK
CfLQSKY4+lJUnFRfmjkR3rLUgu3pto+9AuOOtuKoB8DjRALYDy+/bWCmbn90hZ8yj9T1NClKgBpd
8ghVjZVM8PYL+7MpHWqbC6+lW/MRR08iulpXLRz55G8Twz7YZkXKBgySLDwMjXV9eJ2FSrWxaMVT
roU5AF/OwHjNXByz/BODMbS+juPEPAmDaIjNsCZ07pvZYAuGmLazoPit9v4lPvHQC25Yk+P/RM0V
9saHmxCW3Fusc9fh3G2pCGhX2WTnIkMWfTocX8rBbRczbeTiYZxodatzDWA/EDTPJAMkJwYXbC2S
qylgYKCqMGITTOzmxsiXfhUGOWe+AOVRetHZByXUYzRbddFvW3OPeBOzqY1UcL/CVldiHzyQZkcT
AIu1k0NWWyGmiov1IDzn8obcPw8eKQRTt8Bc/MgILWKSA9JJQtLoQVcLa3RGJYM8StiXBcvUGA4M
IxYFDThGyKF27dtKdwHCmKn1GuIrt7fAHr8qDMZiapLPrAEfpxl8V1QiudSHt/CMy8rIz2Aj3LrE
h7f9rbms0pyI2sqbFMiVoAHmXe1jwrRXFmETpUAfZpNxUN/KnslvRP8v0WhUBCjwj6OCjqTpj8xZ
WGOvVSxQqki796lotsvyLA7EuNs/vXPG8nZnAv236eDWF2Qtxg6Dt00vEHgEcEctx/e35hVWaomO
pJ4f1bELz+Ls15uiC9vuKoPVW3y/BSUIaBxRJBxo7Vr4Sw2TTLSoreptI48SzYC0NskZWahHuVkj
1tTCHKY45y+GAmeU2HXWKBKyoMQyv4NunxAF+Y2aNR5arXq4kn6XwH8825JHHEv90AZkpxKgK6UX
nwZLgNVbuL2g6wNyghZMmErFjP+Q531Hew+uMqRCUzN4GweYzhqBColdp8ir0L0CNLerCt1if0Oa
HA+D41ZBc2VlRptEE2aqoNRtmTi33odZ0I3ROkk/sL4Vq+xgIYs18bYsIEBES3dXFIHF7HOYFxpo
hAZRHZVWamWn1E9X2++fCX15ERK2F597wYPXpr2OvZf3f7ymhUl8Vee7TjKovCdpXlcbiMIKnQOy
0JgO6rj7xuNzot9ciULmXXIuoP3yvBtCp7lcjvvAtBwrKaFfyheV22Xutpa1A9V0fPW7cv5QJteJ
NKST8KACKI4Hk8KP7y+BrmlErG6hhtNycn6SadH0I6bAzpca8DpgMLtWqVyrBBEOGMxAkDkVjfPD
temL87M5wqUXPARzhD1oz7vIQ7tnQrQYwNrADECpJ42MztgTac7lJEKBp15nmapcg195eEemoRBT
dT75x0rvaFaCHQXk5crT/xGiGt6+AYY5o1s0CS6c4qsMrdI0AsRf4wm8dlQ4Phf43/bcEt46VzFv
FIWsoFiXZ+ziYjwsbNU53K1Bzg7G8li+MWnSLKWQhc5/+X7nwubSNlwgyaGRZsWQX5rh/NA2icPc
VTl6EnWRQckq7LukOo8h38ijbwmAioAZdc5iaTp/gD7UnuKWm0+m2VIxD7cxImEJ6MW8EhuKeG+I
VTJX5148aZbdNfEeKV95Pf1Hzksdvgbv7A66ReiGXZlD3hsMvnWp1chc7jzU/4zquL/efJSuhQN+
Lssy89oXu8JqG+IfI6DGb2KCamWVr+svNHoXLVqYk1CTBB29hraEFMlPpu25M7fTXpO9uBN481dK
+vDaCVCiiLH/1oUdksMOmLw4nET62Bkob3Jhrrv3if4DdwEHBs8chWfy+iMARdW8/tPstFdkLLiP
Tx3Kjr9MuQZrGR+wkYUdveokQvrZt1zUT6KiIlv64+XO3OoCbSUEZrdYowXeFJsDTxRIYPq5LKbC
vPm3JcL7zA6UB8pcog01GJ0EESM3rcAnhecjrPyoWS3SmdCN+qKZXjxEXLqoQCz7C5pqRCogSUej
bRpCTTrPhDZQZfyAbs069m2JcnSQpBx1fjIyjPnxN8KYjHlI2dEWppvHifcV688aHSV1P4ZIc5gl
G1/QM+KAWfysAvwz/RnxJlU1eJou4XOxq7JyxPakZL25Z+rDxPO/Zy+GY4e0cKQOLUu4I0TdfvXk
VATyToi3gIsSv+wi5GXf9Bqdn74PvE7Z+JsCc1xC1J2KWUucwNtongKbqFA59EvFuIvRAepPlpv+
RH4PhxKOrraBT/EVNh6lgtnxZBlGgdVviZ9LgqVBiGein4rTg6fAfwOiZbsMsz29TA0Z2kHuHdBU
TzCJh6ELuuys9PAakPJMHQ0kr0PxnEU77j9uGynPlChPJSxeodMzhd81rEII4IUczqrUJ+FQLdXi
vGQ/pTHdacUhGEf/MS992f2gf997gN+XQUSzWADz+Xpw+DkcH5g/n2NDDa9GNByP7Yv5oVWWhWCP
jF2q+Jq9SB136zOBcbCNwGVOR92eQvPmpHUTulvEbwteP6HwnZ4GDYch8GOnAFDlaOT7N1jXJXwz
qQPRsPL1EcTBFj/VUwYUKdC/1eof53rqfn3XyFvAN2XHF1HHv4xObfDRwTONv9yG9jTgMD8E/NI8
8nRnZmmOcARjdFw2pEyM87YydXZGCSaSwjA8Q7FaS/GbXyO+Wsj6yor91dfCsne0ZtD59pehi5pD
lbhbYi1LvhkY/PXozokbswz/pm6K4hbNOBiEq5khfOs6/VRPIoJPi2x04LzSyZIshC7JSM5iJudx
tx2dcmDjStMHa1eyQqX+jcWTNBOBD4Bl9LcnN2ujahYlQT3zJLeIoYi4UA5dn5YZWL6kqesTaMnp
gWRbjiMVGd1wQ6TVSoXa1CfSUgwdAp+4qTIeul8x4shz5j7ym7+/zjCL8RIzJsSQEbyNNSp18J8f
RXjTjGaijZmNUIeiGgxp2CgOLgBZDuIc5RTvnb4mVvgWTOi2S5yv3Tp+JVJUgWM71aQarhyH8IHY
DcrR24qtCv2D7UF9LxcVa3ako/3uJY3pU2gDhNpDZ8PRVMUge3xzeRE/X/2YKwMX6WydDhMfuYSU
yNjs9+UwGFXerICzGcORTvq8Ooh7WhTxt+VdhxlDu3TWaj674gpTtNhEktBOojrOo+CifhPDT34n
sT7qET1PkjiMJBjcQa7qbd/Rxe+QFyDCRIsq8Du2r181KMMdn6zqUkaMUFjurEHPdQX5LVzZlBKC
Zm9++XmvbP5/PudHhUmCtIjkjjQEgFjxWJ44o3rgBDgZ0k1BFiWNw5mT1qvTJc+A78LjjNLajnic
4j4kboKjcSb3PunJiVHnxBxm3DACJg8O+qSH9LE5cJrFTPPh1zu0ZjCN3FVHd2nX+q/LqcRQciSA
HySP7Z2KkhOMldu9PgHwncP+Y4fIsDS6vtF2Wet8hXCE9Jt2mWWX7I7mdQlP4WagyVqOywoaPLHV
94aKmryLwSrFT74cGA111MUTYrcBY6RB+jNyEYnrP+m6WOxYdAAI3QmUzqgdQPrtc8vNSu4MV4Yc
saQTUn8D5WObtINe7jk6YMF1V+O5O324YnQ/1VKLXDGSH3NxbCHAAy861xBB19AQYr2dJ+squm+2
sVj3lK9LhqQYHkVwkxcvW1OCZl6L5q18523xtLcWoNUXcuJaFtgtwvF9eIXGrxDAw/LHRS8VBGFc
s1fNIdR2NTDdQl3mdykMgimRmDuOVevgi2c2oQ4+XZzfYBkvP8HMaNSWds+M/+uPI4Y/ezR9P4wF
/L7oJgUIFamJXHIl56VIw3wAszTfjaCkl/JU3ReHjk2CD/dNBR9MDq3a3MOGhpdD74fnX2sU9+ff
ZvoRfsbwanCTNEFr3JY16N7nM4bvc/myT9/vv20CPxuV+jRjVc90zFVt78of3TYGoXZvkBfBCSmM
2UaPxieUcZauXoK/WlztkrHCjmFgXdB5EJT7ZOxgyki1v8Yxx0Lp/1tEN1KF6P2DubdGGaMDKXh5
PDN6bbU+d+6ZJV8RnaRuPlZspTPEjXkKP8Dty2Vj6zja9jOewhjPAxhFsHs5VrWUoVaWDL/9WApB
94pvTVWXAGRjE4W4Bc51qr4hYQF21Sx9wLDRLNdB2BqW/0uP8VcrJsHu6n3agrTYtzrI/nlRcl/G
Y4RME2VzgMzOaAK8AB82VEuyPrJFajStkEJkiuSRlHGxWRhXiGItLPsSIcS03nVno7d9pOGr2mjH
85elJK1lfVKi4tOXk+hvdgRUJQ1Z3snTZ+wlfQBCYYE5MQYRbhVXMs+iRpKGRmcAtTA66y6iLIf5
Uq0lNIvfAsM+nHBm2f6m/O/GCnO2g8rKHgHnuSQxCZKPjqMYmrIX6PrgTOptQ+1dG9mc1q6l1haT
3FWsR3NMv9FTZsLH9HAi5A7WOKGG9cLA6jKYn5F5RfnWZf/h3bReEdRJlY9Fso2i7lkX9Q7DTNc9
N11i8Z6cFTsu9F4Oy3qpkr8k7JiJQH2hrfK1asFGPJ8p5/J1ZE1EBvR286W/b+OhCCSeql2dxsLT
yGd5w1XcUXMIVhTgW87qy4d9Uf2stH8udVdvQuM6AuGjkzJWIm/tb5iyVbvsyt/9zUJy0O6FeSwf
VoUnLIknPxHZYpJzrcQMT/dw5FbhpAC01q/pl8Qepx6+OBbxrn3O/Ts2R2q2B5DOFVhg363MJYDe
XGGBvikbn0zOaHdqErG3I748BYbPm2nzw99TleUCPxQMXX7h1liDZnVBbvE1fXidwOdzPu5E//hB
bRZQPteZpWAzvSOK6IigG+Ie9WmEJOSgBEcSJWXWRd3JZXLBd6aXh6Z3Cwfy4qUvcyIdbs8YS08G
Rrld0CzCq7ZigRAXSo5CcJdznqqOQJJiLfBCwwRILwivkqnJ/Nc2NErmbY9SJVfmxuWaFq3vaNfk
l9OCoqiz3OdP/JQyivyFRvYLma98l66QexXMtwZjSqX1m+IfRTcdoSanSwfLD+17HGty6nN1OxUI
XfYoMXtUZl+2i9yqPSkE2WGPWoYtjfQmQBGOt7Au0lDNcd+aAxDHb8kR0FgfAl0tMc63P9e1pZdL
pgmZ+MbkE7A92u6aQX3AUXkYIqGe8HjmpCXK5oddo2DlDjXtKCfpIQPLqQ9OGpvtuzshhxNQFM0W
90IVoX3TjGD1+1glqd7B/Byk3a4HOGrYtocBqrAEY28HajWkkUj+jC4EIP8MxpyW2md4VmsnYck8
WU53y107rbLf0Kk/R2GJN8MrWDjSMGMOVrkGJ7f7Oxh4r1assZesmMiBlQ3/skkdp+4/mkffbi2R
KJjsVYl5gBs1MuKnuwM7PSRpnN+L+67uz/M5Nlv8615qUdQe50y2nMB8bqnU8Uh9PnuOM3/CML+i
nReu1o8Wx9tEOOtme2CsEItfC/Zlm2Ss5dGMUaICXJIjPdgvvZy1FrPeiJdqT6fsmjtYzYL88Wth
ytQtkTn6uxA5o8K9TjhF/rYQV1FdxBdaGIUYxZOrJjJo0/X/Zuh/dmSrM3RYXqcv0tBwlWxNfIYw
nxhloLEjh7806VmiowFJD1mEe/j/fLD2rpzHwmQRp6Lnm4ppqGU6tIoqEtRRTN9cOd70rnlrgOZU
Mbp/9E5FNfucjpWu8Vj5Q4Vfn8iW5kRIeUoSgtHhp1s9UO3FPClHcTr9P4x/nHBHYDYHtTfg+HUE
rJVVSF49NdDl4rCCR2TeyeFCnD7wJ7b29r3KQWuUF45qFIvCrbOLKzomyv4v7Z68jENoHXbSgJO4
NchbQ7XVQPyymbO9H6Wz0IYeWTSeS0iDZ+JSjoraBoS2MWrKnAg3go5+VRaqnkwgRMHaF2wzDfg9
mxbNJFUzJWsa2BmPAublle7/FbzjC3aNyOPTcUNfk0Uo+61bGINF2MmF6faNISKAOrK1mXAUDW+w
evIMy7knUfx5fc8XOPhml4o1yI8kNMNPFerFhMYj5vz5oghFZOPIxgcWs9xx9s/4RUGbNiqrZCAO
cGA9mD4GBFbX61vDiDsi/pfopP20QNgy9n8kDvnqKWvIyKBy31EMhZvC23QRCXgIRFaqrcArrBAU
lWrnT4kH4C4Gbb1UyYKy1H6CfUU9gceaYQihDkeuG39b86IO2E5uK78rK+5wHw7yVywhXl45Q6HN
Ftt/7nFHsO6L/ikMp3NkBjf9ylEsyesXX30Ex9b0vQgKmxp7wTOqXr3llQTCjsdiyl1Lv+HPgOlB
5o1sbwFbSuOWOQ72+GGDoFPf2DPSm+XR4hX/QPrFs6SaB8y+Ql30oMcdTRxGtidNPVh8KHZV851p
fRzjiH7wxwi1dVelotbAMa5hjusfAfc00+6+UGF4i/hjHGuu/3kkdRw43os4v44NEAmpzhEoV0al
8aXlNEeWoVsB0ix0i/ndNVbXbTBRhLUlJVwYoLdtwtb+8xXxgxJOoq03RHFnVmhLBNaoHGdkJUiz
WkOBxZ0yqEO3/Dspfvo4Llu54DL8dyq4C8OPu0aQSRYNELwbsZRxKQlL64qJDjKjL6yfqkyzb+jr
fAog8Gp7XRTmYK1bcVKntvpAKRO2BzjhFzNLksPs/NQpCYjYKdExkpJeZrScGUyhv6O1C6oq5FCm
p1FlNwCmgyXtPPArezTI/INWD9Bad5+5xfEWg5TsxxgodLKX/rvq4KOzD/Qg6VUd+HqHCzdHfBGS
kbky4V9A0szMKPV8x4/3BAIPFj0PBOGAY5ULWoG9o8gkNXk93v98qQOkX1f30PVzzYNtXgsmdnyf
eLZbUu4aotfnYDErvK/emW+KvpszgaUklG/k/sV4Gt3haoHr8YoPv2aiEYZ/gLGC6Ww6TRlmwa7V
qFUWcO+p1K6E5ycbANebZcm1tuR04d/2EmPceo5D1bqNQOgDg+5gbcDOBnQgECbZPTN1cYXpl3AC
lSMOLCjArwqZyx8QELS3csArO/9Je/1WMfBjgb4QjGd4GbEz/MQUtVoBBsKsYKQIqeDk4a5OWm+9
f9cwlz02KfvcFwXKAQZqABSkwFJjsisovD6Xj47M9Uy2I6k4NxWw4yF399aLhUZzy4W0OVe9K9tb
M39mw6vTX+vVO4zaJ0wxWk2Nc15A3ByPV23psMFE9wGBfEU/59Q+LeBHvkzY1bCEEDBQJsR3npin
qM5uYik5eAXGwc5rR190hMUBeAJ4ZTvDUVDlow5tt8a+4SDZOayLiA+gVzOZRHJjyscAHHBY+CNs
lL39Mz5lobZYbprYehoEwlBk8jYWvWjEYnlGnAwOyb7lEND5YWLOAxtcDtCRVI38CUZqBFhTutTP
tNa7NaRCDZKAcV7QH45lyCxY7kfWkGC0qmoRUTVDxzEmFwazTRZufqgdZqOdMU+Ei0rDNYa02unE
BT06qTCUSOg/EBo8L0XFlZJStd25mAnWGESk58AFLB4qczCanxDdULo5+TDK9ru/WYDtVemQy3ZZ
1lYh974CXX0BfiJlfaSf8mzipVDZTImccrWtcMRo1gi8mqoPoK/XUz2VWjTgfNlSqIscOnlHnMC5
l3GKS3KE3d+iD/dCTvScuWvkzNlDgxjFukO/6v4WTgF/GesspJ+2orsLtldAtAHwpQclvNg72sjm
NYeWc5kuvp5yE8Zh4arOcCjUkNIlX3KFNfNQrnsPVSSA7pZsIL4kRm6D4nKEWE6JUhX9oRryLtaU
d31g2kDw0Hz2LvyF/isjs+F36SyftNDvOtqc23hvDva5ry0tBQJxa2YYMY2FhuuBWfO9dF4WQpJw
1ASFKfFTfOQwUgBIYjBixD/fPc41DURMHlH5H26O2GwZ38pQq8N2Pg+t+xHcdsWpvmkQwyQlnfVO
mFO2OLeI8ZRCfqogD8XYdvzmdUPFJ1U2ozxHacu9M6fvLXXR0xtj/7/dsixYFMIKOkKYXW7Jow9S
yom4PgAKxf8y1FgAP9YarNYNIZ4BIuRJ99vQcisV099TBdrYR9LxGF8yFqhCFzAwzLZQ4ri/dtzv
warKoN4uj6GEUI3CbQerUpo1MK8YThJ6+4RQrK3mySm1kj6Ftn+IQ0JkLVqH6KF5VQp+/Ey0g/Pr
dkdJ3+nXm2Z+CqbawLcFUGzl728WG6aawwCCmlF4fqqAmu1g0XKX1wpd8ktHobfmnc+Pz1aGBvpe
o+A7E6V6+4lwduiHbrH+K6wOvDH9bhRdb/39OZsGBYmyt0jUqhYUqR7ewDpfCx1XsxAE1VqodUCL
3bhv/lwOyRhaKyh2MuAn5K2oqUaJsz6YkJtirlp630SQQW9ttjqIiqH3kLWv8bgucs9PSQoyrn6u
6nsxzOtAlhJ1xkD30fYxR4NtQTf9kBqKz5L/kHHsRFGUhLhpYHxnfbH8amYMFDa14ZW4vgcilCgG
nubpbZZ718VRnXhs9KFHqusWlCHbWVZs7qaPcFJANyFal5bs08gEPvsDOUsYNgEmnbAfR/1RY5kR
e1RSIhb61ZKxzr3/qKHBiikqvk8ZS9ltoqJYfaIZZy677bRredtd0Mg3kR95L1LJYZ3Tk2pdADut
OkMDEcCaxHOUxYKtljc+ZpJqT6iSDq2wIqfgyfaXq+CnrQUI7Wzhsef+tKfLWNLfPRBk4ikEW9KQ
PO5v68pVwNB6nkIUrBiNGe+vGjYe8+dxREk4l+/LXAdGKgoBBsgiYf9dy64Gpj8eNHDGIs8bbRLb
iBzl4T3LkEPHanZ243C+gWgdtSjOzCMlppZaCMC1RyhwfrGD8nD78EsIfvbZCaYyajQE4ZOmOQyg
L3Qo5n5hgEfv8lNjkO1Q3vcBoNjCTLuf0GCg1yAesUPtj4hsbTXb9z3vLdNHJlJWBh8K4YW86Z1n
JVSPknK8/iSwlGlqsH/p+Cx2YjjzvZG6wwkead+O6mS7rwq3WWg/YzqLZRWJ0vX5rrqK/6rptIUH
3BrntfzpDUnTOTiLwxRg2ask7vsEgBbD98oQPtHNYALkA4zcu8jj2WPgrfU1QKhj7kbLySA97DUO
XL3BytRpqgsDjGWTlVW+QhCrpnvo5B/s5LIzvXhvMIRxMvgCJ9owDcFCczaKFbNgr+pqpvsNAND+
tt28t0AbkSy/o7116b9QpSDjozlWG4CXJjl2X3YlpFZi6tXBxcYlYWV5nYlwFx1yRP1UvO+is2dI
hH7LjULrsYBaBX7bfX4rMRRVPqyhYruGqjOysGuqlvSQQul0bK+LeV8T457qXmE3BGNs1zZ07GAK
gbEB7dUw+r7AMakt8xAmyd6ZG1uq68grOw2MgDTowk15KtsCOcljyyiDZTRv0BtnzWvHr+P/xwYv
OEWkbCBZ+R33uxE5PHY/Zol/NsWu1AVivWtAvEQgvHn7DIli8B/NS9IDMkYIFMZvDry4nOIXhYIb
/h6n1fFstPj0HAN8F5JQ2W9ELeyZtYdnc3+6hwDg/Uc+WuZLNDPvJcxI1pPFcRHYzU0VIHzujhH2
GOZE1wP7whWPqXbJ4iFkMM6Ux9ZQxGWcV1QUckgmTTb53LDzwrX6lrPITsy6R2bnEpBUWQT1qfim
koSTSqI0ulv8LDNHge43nUcLjXZ4UupOZqwItPx9lOyuhguxuggQcTUuf/T4IUDvsJ+I/DDZqvY2
Vi7gMGjSsd+sGgQ8cABxO3GT91G3S7LwsmcdFjFYnEgWzwMqNdM8AjHZupMnDc8ZqCMM34G9l2ex
TB8Lfz3gk7l2aUTQaXWh0w0Y3h7tmRJIwWremaO8q9sn+g6QdCR9wHCAq4nC2/+mDCvNPV8cIVSK
0uZF9Qn0ioFdX3qWzgeHmNxNblOXplbkRQJ1oc+7c9ueA8aiZszoL7aaBhtZWzz4pKsVxqQen3Np
uGMOsKQ+qNPBwKzCRh7O/0sqCpUnNeN2quVutcacOKLUub4Q8qudRd4YwsCNtoda/di9e69i81hW
oLv4uL59mG3pHN5HIOggbgoJnAxyJ8afDNl85wt5d0G++i8p27wMOMS0tWEn74t3ulACoy6JABkV
Wuo2Qfmd4ZtUULqWKMRfReWSzIGQt2DVgGX16wP7GgEdgt721NFpj8krdmAlF/N/T3eBF7Iz7yzN
Wp0tSL4Tabnr7iOf8L5WyK3QcV40xIGF1CCE2fkn8riDkerkId8fDH3QM4GrXUhM82V/nVCXQqSL
ydzS/M/7VkB9Up005hRnSSi/Tlf9wyZsp61ghiFzcVmXY0t7SdavYDtxcqH/iHPAn91R90s+dWnU
IwV1Uj0svK5UtF6vy5kElNrzg5T1OMeW6YezBRAote8fK4FXme9xcWY2pYVX+CHkF0Rqw2te5VNl
ybOFDOPlr9RJ9ZDddhZVX556vPGdD9sdDeRZ0/ttSM3QFQgoplSLyU2w0OGdhh92TmY/TzsQOyYf
kqF5dM8LHBM36bwTUSpj3PV9bBmxucog71L9dzMRbCscSEh1jHnQ+OvoLLfiHwVJOO6zRZKw/P1Y
JNfM2+swLafYZtwzBci4msslF3gNOVw73q4V3EaNmTsyr4aPcbS9BVsuNRRk/qLK++PJCNDJhB3Y
14sAllv15+MEAOINjFeoQcx72qNq0K0RboDpFiowtqVCtRqrK2jCpRYnwk7AvPfqUR07FN76pZoj
qKoRBuwlikqmuzgWoDnsHtVSxQuaHBO98rNMF4Tt0osWj7Zlaf7xDKRdbJjrYyBfOxcgsVN7pl4/
Qzmpn1YUTy9aujtEPzqBfUB2HTd1zDcSCuFzrlw0L/RL3GeOZxrCGFsABV2rMmuFwHePXlsA8ANL
DacwBGs7UbI27fZndPDlVlsAFhP1oWt2C+aOHXKKDeyNU4vWhsU+buFbkUBoc3RYiJqAS3eA9yq+
Rknd6jd1iTMGJGMAPOihvugiJkVwMUvOnCQO6zPHaABrho0IXcEYlWa43zRmIHZwpzWEikw3ngEm
VBGN/VlHRnebc1x0FxzurSp32IFr9sy2J/NZvc0f7vfxC2POf9ZsmoT2cM91VsC1531wsxM6PIim
42N8jCvWqfxiAlZsuPnQVX+aAVKb9VQZV/mt4pfFxxuVHy6ctT4+6Lj7FAt+6eaUS2QUM6fDxFxw
8Q4exL08zokT6WowRkLHTyeeYDyWWT0BESRTj51GbQreR5hvYBrCWjtDIOoDPOrs3gOMsxqBnXA3
nYHeAj+8KZpvq+0cLhFYEhjPjIVWavWis5/nfcHZUAsfjVA3QUPM0fQXpCYJHpUinfl/s1tHxq+H
XrPCKcKBjBJIuasC/yy3prHNyr9oVHIi6bRnrQLNbVGkwpH459WIh5nIduNER/Kclh5XKF1IiNad
XAVm0DHxBlpJGASHK7eHiGyRTfDbbM4Of53rAkFaBzM5GJyIEX9J0fV1+kyqtou8oUCkoTzxVO/9
b8oTirCGO5G6TqkWa2hl/L9Z8Pa2Iysc0aJXkmFsecJayvp5zaxQ70iBibseUTd38RqHPxyY5vP8
GfQdZpmfNgVApqxuZ6VsWtnZ/6Ll8E3CpVF9GKW290hNP/uMishLrKcDuXP18jF9dXzABuWBcs5b
eou9gTYWfDIXQvNVNLjs0SJaNDha85T8ibvRUxYaq8ela8AVc1jNYOCszA5kUmuMvN2q3/+hZHi/
1xHgf05cKvqDa3KJFGH7ds0kAaL9/cuPCDCvGF4V+OXAUsZvlVzKBF+4zfmFrL+MMnvVVrzUzDc+
JbBUt13rTN7mUVwaSjB6Wb2vufJc++86bpDB3RWPFUi0WT0O7VkpcewVOB2eir2AweIOywi2vJOi
xKLhDGt6Kc/7Px/wFGCDG8FWj78/vlEF/QDUoMCnf3aYvrnmFoSCJ01Ycpcdhem6O49kbWggZDoK
PV1P1JBpbbs+lqNnxsWcGJKfekw/7oKORMH0PRNLA5Kq56MC4sXGrVStsDVNcPE/xuyxUpj6PpAY
8JIpXfPyJVq+tOr+6KkcS0R3hYFC2pkyTwxFVwNJQei3c1H2iHHGDrcyYiPA9gow9edxcspK11/s
VNlwHgNEbNN/vBhUb19PCx9BusoTQpsC2D/pf2DD+ZUY0ufNLxAXhCHut5ezaN9zyWedWr6P55Ih
jQik1NtgfQ/P4CwQXjRYM02YsnEzJ6oNQ/tCASt291lMhHnwd9mAymtxHh/xsbAuLAjtaUvuARhm
i+TinLzUo4pV/1v+P+MLgLruN9lbd6HukF6QVEf6CJv487EpQMaeVCtZDTliMNri/d6nbfpQr4V3
hAJRuDNYpeU2pKm+pLxRD+B3FPZbajzL+O1Lh2p9trJJm0mS09LuDH7qYP8NDLEjFkP+Fw8yfCxg
D8iRDZxOQnAW1S1NPcnRi8bjijImPB9UHCRp+jafRd/zrpr5FAKKoeNYVhh172EPnd+aSEPngPoQ
QGpLQjQZbG0aOiZNFfwtGgRX2QCon+u8NlSPOWMRpgdwRnBEKllOA734UVhqeUdi375xr4Zkaa1y
Pbw1rlUVFLJwNEIbebyKGV+TwTPeo04nI1P5OW/K21QPT5X0wLDsnSucafLk02TG0PaJU29Xzrh4
1LfuJu9p8iwtowTAC3xlVA6DlCBiSurKdYFX92A7mjyg5dLtHPvpSirdgdAC/3X/IKP/WDhGtivw
JahI4BqHOuyuT5CH9468xHRyNfHvMt3hJfFjknWlaDdgMueJDgYwrhXJuYJfIF43QwBw5iDS8O/I
W5aLmsld48E5kM2W/LdXb0+hfBMQ7jI01n8ZFbKo5rgM8L0Yql2BtQDB4Gz916+WJhMJGNNHKawo
+wuIlap8UJnu7/+CGf4E6ZJdsIH+DZHiC3K1VEEwsWOdq+sMT79Oq9Xw0Hk7M9XrRgT8jZVwvccy
SdYioeC7/imwqrzxnNihjvSW/QFm61cB+wsH6/ypUmKhRUjJON8Rng92odpFW6fUWv/q774HvLFQ
0C0EbogjQ/tXQ7n+vhpBsnMCluFg14IaWOHIgfflba4mPSBwgZ0TOLNaqHWm4L1ImPtdfGugLJPH
H80Zm3Wkd1bKA+WFyQRJz45RbpmLduEpWS6ewd99vGVNomi7d128OkKBYKHr4/eROJ+TmtctgtXk
TjIChiIwlTxu8wGm3gnZirx4Ni3rrlPRv7g8FBgU/2rR0aPMOKc8JrLPyrBSgxC64/ESHjbTwiMI
Uw4/aAZT9kNE8LAjih7usQ8eyDdEQc5O4ibSRwBn++Ugb/9bEjomlMuqCKGRQJNh9am6f0seTVYo
HWXasp9R4iclXpPAbiLWJRBWbibgfFmehBmOOcAdusNNJvApKzeyxChPgxLh+d0rp0xu4DC/g0DC
vv/qxphWecwcx1Rdi1pksBEdwXoCXVUJBcVH3I28J/jIIqFjX3a017wFDOKLJRWNXUJnHtzNjeFO
oCITO+EpxTedBViZjphmEWj1GZETK8nMqG1R6hapcmSW1T6wOGZ7rv3V8vN+ofHzpCygul1Kv93W
Qr3RIOSQKr/UIx2ey8YaKAYdG61G+uupMHZ1Wey+D62jV/R0E6HAL6h7ZlB2AVoDU6zGKCm3GaCi
10P/+/moMqZmR2u5cvL+w23cwi+Sl4JGtJJp7DrKtShwx3X4mLvE4jKQeS1PVhwuO3uDXG02Bva7
g53zPMgylwr9GkTQpFC6J5GS+aDGK35r6mJRE/h0I02ZZ2gP7ucWTqiuUL4FxFDic8K5HCv0LnXJ
E+UwZL34/bcz1FTpTZT/LeRT40aQ/5E5Wf3dWyp6rtj1TMpSJpZCh7J8bEJQtQ37+pDH1m5zrtW8
nUAAGKTCAGnDzE6POtJK1xkPipbWkwGnt4XD5V28rBIDpw2TBOOO7SVU5YM4CxNjsWhMHjf40l4u
abxBiTrKdRkHks1BmoOXUlN5c6VsR3tB3rj2GbTRpF6DjNQE6WScGM6EQu1TZlh9b61dV1vSwTQL
KfHEvtgRFL9Rkq7ThHX9bBL9vBQ9CM+5Z5lMgLVx6khvDmO0fnLCgiZOK9bRg/+q7e3dkL29o8I2
zFhfnXn4nFX5OEn9IWRryqK8tnOhDD8P7FyaSblZ2EI7Acdv013zfAbtBK6YGrB0m7DL9l5RPiWJ
HNUOVBQmC4bzLUZ4IH5vpMu+GT3DclRrFFP17CwJBCMOQFEqa6lQ0kMAR1pFrpTef8DSKf5Es0HH
r4ksgDiUUO/NiPYXxONhCuGVuNV7rMkQUwhBugFVrlV+zqwhUn6maCf4vLnITcNfWB8MG+2bADz/
L8skDaQQE9IGlB+jGEQjM/VWFfJYQ3fACvuoQLVJAku46e586JzwjgU92etHsDx6h8MRM+cz9k4i
zBa9iwI32coNq++SjMVJxl/VQuP0ppfoPUKppHCvtqHRHS5nOmudT1Y45lhRkiXdmql4VI0Woj6T
Tjehtf467eeKYy0/g8b3w3jokIiLaoH3tVSw5qz/JXMv5NcMIfKKgtf3iFdrRDamfeNfAYqhUxqw
Vb5tZ/feVy7U46bhnj56Xgz7Drjvmc/i2w3hq77WbxUNuTp0OEEZYsIzNsE5PIrl77krQbQ8fbLD
EjENeRsamACuqOI2UW/yzGWL8ILsSLTVXcypLjCIOynVQK6Th9rYXzAslEvHlQ24dpl4UIjgUWk3
PlANKiuHjBkVE54bSRmsm/vhauR+VNaIvNICgf7U5H+m/V/cwgIgYTQneg33yY0Qr3bjQ/R+pUsR
vdmSkZQxK0EZ+7jagSJhZjA8b/LTmGlJ3UKIQGvrF4hxojteJTW378r3C13VEyu0fLVc6VR6ex3/
58ryKWrd8GbXtwr93HW1jXcWMcWVap5swB2zs5JrHyP4SzuS1X6euPxQ4M4ZThThb6wTRKOG6yJA
tIFmQL83Wu8c0R4Rw1UCMqUKRI3lPG2eJuPmNGUZc8tSy2XA3MRXxvZzmm6YBEuibV+w0AWvtZ8e
soHG8RBwK2nVGPY74hlYoJxXAopyWNMtakWpavi/xo1buCLwFVJrAa7D9Y+Q6XY4uzMngLp/gAxa
Pz1O8ql9m1/opeN4DCIKd9Buk23ioUNivlzN3t7aADe2X1x3w38TrKYvV3xCuhJ75n0r9wzmGvRW
khIMhqpnQ09U9cQtwp+aYuSf0pqTeSV4amicx9Haujji5Zo=
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
